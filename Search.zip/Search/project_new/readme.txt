configuration details - server
-setup mongodb and create database xyz
-in xyz database create collection user_datas
-insert some data into collection

-all the dependencied are listed in package.json file

-there are no modules installed in project_new(server file resides here)

-open CMD , go to project_new and then run "npm install -g express cors body-parser mongoose --save"
-you can see the list of dependencies in package.json
-server port it 8080
