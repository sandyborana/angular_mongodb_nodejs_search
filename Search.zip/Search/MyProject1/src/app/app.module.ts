import { SearchPageComponent } from './search-page/search-page.component';
import { AuthService } from './auth.service';
import { RouterModule } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { HomeComponent } from './home/home.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { RegisterComponent } from './register/register.component';
import { UpdateComponent } from './update/update.component';
import { AngularWebStorageModule } from 'angular-web-storage';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    RegisterComponent,
    UpdateComponent,

    SearchPageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule.forRoot([
      {
      path : '',
      component : HomeComponent
    },
    {
      path : 'register',
      component : RegisterComponent
    },
    {
      path : 'update',
      component : UpdateComponent
    },
    {
      path : 'search',
      component : SearchPageComponent
    }

  ])
  ],
  providers: [AuthService],
  bootstrap: [AppComponent]
})
export class AppModule { }
