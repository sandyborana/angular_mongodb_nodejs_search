import { User } from './../user';
import { RegisterService } from './register.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LocalStorageService, SessionStorageService, LocalStorage, SessionStorage } from 'angular-web-storage';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registerForm: FormGroup;

  constructor(private router: Router, private register: RegisterService, private fb: FormBuilder, public local: LocalStorageService) { }

  ngOnInit() {
    this.registerForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', Validators.required],
      contact: ['', Validators.required],
      address: ['', Validators.required]
    });
  }

  registerUser() {
    event.preventDefault();
    const user = new User(this.registerForm.get('name').value,
     this.registerForm.get('email').value, this.registerForm.get('contact').value, this.registerForm.get('address').value);

     this.register.registerUserDetails(user).subscribe(data => {
        this.local.set('email', this.registerForm.get('email').value);
        this.router.navigate(['/update']);

    });
  }

}
