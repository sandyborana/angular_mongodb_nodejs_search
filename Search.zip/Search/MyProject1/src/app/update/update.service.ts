import { HttpClient } from '@angular/common/http';
import { User } from './../user';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UpdateService {

  constructor(private http: HttpClient) { }

  updateUserDetails(user: User) {

    return this.http.put('http://localhost:8080/api/update/' , user);

  }

  getUserDetails(email: String) {

    return this.http.get('http://localhost:8080/api/email_search/' + email);

  }

}
