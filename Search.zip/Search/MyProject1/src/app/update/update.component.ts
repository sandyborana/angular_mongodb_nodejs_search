import { User } from './../User';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { UpdateService } from './update.service';
import { LocalStorageService, SessionStorageService, LocalStorage, SessionStorage } from 'angular-web-storage';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  updateForm: FormGroup;
  flag = false;
  user2: User[] = [];
  user: User = null;

  constructor(private update: UpdateService, private fb: FormBuilder, public local: LocalStorageService) { }

  ngOnInit() {
    this.updateForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', Validators.required],
      contact: ['', Validators.required],
      address: ['', Validators.required]
    });
  }

  getUserDetails() {
    this.flag = this.flag ? false : true;
    const email = this.local.get('email');
    this.update.getUserDetails(email).subscribe(data => {
      console.log(data);
      this.user2 = <User[]>data;

      // console.log(data.toString);
      this.updateForm.get('name').setValue(this.user2[0].name);
      this.updateForm.get('email').setValue(email);
      this.updateForm.get('contact').setValue(this.user2[0].contact);
      this.updateForm.get('address').setValue(this.user2[0].address);

    });
  }


  updateUser() {
    event.preventDefault();
    const user = new User(this.updateForm.get('name').value,
     this.updateForm.get('email').value, this.updateForm.get('contact').value, this.updateForm.get('address').value);
    console.log(this.updateForm.get('email').value);
     this.update.updateUserDetails(user).subscribe(data => {
      // if (data.success) {
      //   this.local.set('email', this.updateForm.get('name').value);
      // } else {
      //   window.alert(data.message);
      // }
    });

}
}
