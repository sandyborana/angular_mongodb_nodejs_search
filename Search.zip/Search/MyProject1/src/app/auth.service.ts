import { User } from './user';

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http: HttpClient) { }

  getUserDetails(user: User) {
    //
    return this.http.post('http://localhost:8080/Login', user);
  }

}
