export class User {

  constructor(public name: String, public email: String, public contact?: String, public address?: String) {

  }

}
